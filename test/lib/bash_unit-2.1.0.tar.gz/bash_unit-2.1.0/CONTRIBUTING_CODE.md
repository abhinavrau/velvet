To perform a new release, run ./release in current directory.

See help for more informations.
